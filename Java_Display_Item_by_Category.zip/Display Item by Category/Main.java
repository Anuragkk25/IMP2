import java.util.List;
import java.util.Scanner;

public class Main {
public static void main(String[] args) throws Exception {
	Scanner sc=new Scanner(System.in);
	System.out.format("%-5s %-15s %-12s %s\n","ID","Name","Deposit","Cost per day");
	ItemTypeDAO itemtypedao=new ItemTypeDAO();
	List<ItemType> allItemTypes = itemtypedao.getAllItemTypes();
	for(ItemType it:allItemTypes) {
	System.out.format("%-5s %-15s %-12s %s\n",it.getId(),it.getName(),it.getDeposit(),it.getCostPerDay());
	}
	System.out.println("Enter the category:");
	String Category=sc.next();
	ItemDAO idao=new ItemDAO();
	List<Item>listitem=idao.findItemsByCategory(Category);
	System.out.format("%-5s %-15s %-12s %s\n","ID","Name","Item Type","Vendor");
	if(listitem.isEmpty()==true)
	{
	 System.out.println("No such category is present");
    }
	else {
		for(Item i:listitem) {
		System.out.format("%-5s %-10s %-10s %-12s\n",i.getId(),i.getName(),Category,i.getVendor());

		}
	}
}
}