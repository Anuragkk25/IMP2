
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ItemTypeDAO {
  
	public List<ItemType>getAllItemTypes()throws Exception{
		
		List<ItemType>listitemtype=new ArrayList<ItemType>();
		Connection con = DBConnection.getConnection();
		
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from item_type");
		while(rs.next()) {
			ItemType it=new ItemType();
			it.setId((long)rs.getInt(1));
			it.setName(rs.getString(2));
			it.setCostPerDay(rs.getDouble(4));
			it.setDeposit(rs.getDouble(3));
			
			listitemtype.add(it);
		}
		return listitemtype;
	}
	
}