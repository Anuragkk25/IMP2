import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {
	public List<Item> findItemsByCategory(String category) throws SQLException, ClassNotFoundException{
		List<Item> itemList =new ArrayList<Item>();
		
		Connection con = DBConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select item.id , item.name, item.vendor "
      		+ "from item , item_type "
      		+ "where item_type.id = item.type_id "
      		+ "and item_type.name like '"+ category + "'"  );
      
    	  while(rs.next()) {
    	        Item it = new Item();
    	        it.setId(rs.getLong("id"));
    	        it.setName(rs.getString("name"));
    	        it.setVendor(rs.getString("vendor"));
    	        itemList.add(it);
    	      }
		return itemList;
	}
}